package cn.exrick.xboot.modules.base.dao.activiti;

import cn.exrick.xboot.base.XbootBaseDao;
import cn.exrick.xboot.modules.base.entity.activiti.ActModel;

import java.util.List;

/**
 * 模型管理数据处理层
 * @author Exrick
 */
public interface ActModelDao extends XbootBaseDao<ActModel,String> {

}