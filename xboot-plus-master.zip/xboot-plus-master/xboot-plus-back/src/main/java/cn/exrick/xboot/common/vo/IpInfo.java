package cn.exrick.xboot.common.vo;

import lombok.Data;

/**
 * @author Exrickx
 */
@Data
public class IpInfo {

    String url;

    String p;
}
