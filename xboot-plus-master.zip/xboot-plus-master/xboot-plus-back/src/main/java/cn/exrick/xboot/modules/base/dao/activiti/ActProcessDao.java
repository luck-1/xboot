package cn.exrick.xboot.modules.base.dao.activiti;

import cn.exrick.xboot.base.XbootBaseDao;
import cn.exrick.xboot.modules.base.entity.activiti.ActProcess;

/**
 * 流程管理数据处理层
 * @author Exrick
 */
public interface ActProcessDao extends XbootBaseDao<ActProcess,String> {

}