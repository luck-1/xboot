package cn.exrick.xboot.common.vo;

import lombok.Data;

/**
 * @author Exrickx
 */
@Data
public class AccessToken {

    private String access_token;
}
